package com.backend.spring.rest.payload.request;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class VehiculoRequest {


    private Long modelo_id;
    private Long pais_id;
    private String  patente;
    private Long kilometraje;
    }

