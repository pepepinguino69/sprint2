package com.backend.spring.rest.models;

public enum ERole {
  ROLE_USER,

  ROLE_ADMIN
}
