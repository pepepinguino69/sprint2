package com.backend.spring.rest.controllers;

import com.backend.spring.rest.models.Cliente;
import com.backend.spring.rest.models.Pais;
import com.backend.spring.rest.models.Vehiculo;
import com.backend.spring.rest.payload.request.PaisRequest;
import com.backend.spring.rest.payload.request.VehiculoRequest;
import com.backend.spring.rest.services.ReservaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(("/api/paises"))

public class PaisController {

    private ReservaService reservaService;

    public PaisController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @PostMapping("/")

    public ResponseEntity<Pais> savePais(@RequestBody PaisRequest paisRequest){
        ;return new ResponseEntity<Pais>(reservaService.savePais(paisRequest), HttpStatus.CREATED);
    };
    @GetMapping("/")

    public List<Pais> getAllPaises(){
        return reservaService.getAllPaises();
    }

    @GetMapping("{id}")

    public ResponseEntity<Pais> getPaisById(@PathVariable("id") long paisId){
        return new ResponseEntity<Pais>(reservaService.getPaisById(paisId), HttpStatus.OK);
    }
    @PutMapping("{id}")

    public ResponseEntity<Pais> updatePaises(@PathVariable("id") long paisId, @RequestBody Pais pais){
        return new ResponseEntity<Pais>(reservaService.updatePais(pais, paisId), HttpStatus.OK);}

    @DeleteMapping("{id}")
    public ResponseEntity<String> deletePaisesBy(@PathVariable("id") long paisId){
        reservaService.deletePais(paisId);
        return new ResponseEntity<String>("Pais deleted succesfully!.", HttpStatus.OK);
    }

}
