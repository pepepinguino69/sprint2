package com.backend.spring.rest.payload.request;

import com.backend.spring.rest.models.Pais;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class SucursalRequest {


    private Long ciudadId;

    private String nombre;

    private String direccion;

    private String latitud;

    private String longitud;


}

