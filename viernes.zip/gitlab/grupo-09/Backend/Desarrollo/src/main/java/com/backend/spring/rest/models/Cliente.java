package com.backend.spring.rest.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cliente")

public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "nombre", nullable = false)
    private String nombre;
    @Column(name = "apellido", nullable = false)
    private String apellido;
    @Column(name = "matricula", nullable = false, unique = true)
    private String matricula;

    @OneToMany(
            mappedBy = "cliente",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )

    private List<Reserva> reservasCli = new ArrayList<>();


    public void addReserva(Reserva reserva) {
        reservasCli.add(reserva);
        reserva.setCliente(this);
    }

    public void removeReserva(Reserva reserva) {
        reservasCli.add(reserva);
        reserva.setCliente(this);
    }
}


