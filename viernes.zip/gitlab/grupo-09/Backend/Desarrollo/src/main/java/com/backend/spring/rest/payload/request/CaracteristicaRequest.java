package com.backend.spring.rest.payload.request;

import com.backend.spring.rest.models.Pais;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CaracteristicaRequest {


    private String nombre;
    private String urlIcono;

}
