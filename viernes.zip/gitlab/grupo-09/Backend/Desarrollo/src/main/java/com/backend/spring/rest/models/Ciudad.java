package com.backend.spring.rest.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@Entity
@Table(name = "ciudad")
public class Ciudad {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String nombre;

    @OneToMany(
            mappedBy = "ciudad",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )

    private List<Sucursal> sucursalesCiu = new ArrayList<>();



    @JsonIgnore
    @ManyToOne
    @JoinColumn(
            name = "pais_id",
            nullable = false,
            referencedColumnName = "id",
            foreignKey = @ForeignKey(
                    name = "pais_ciudad_fk"
            ))
    private Pais pais;


}
