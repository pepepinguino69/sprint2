package com.backend.spring.rest.payload.request;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CategoriaRequest {


    private String nombre;
    private String descripcion;
    private String urlImagen;

}

