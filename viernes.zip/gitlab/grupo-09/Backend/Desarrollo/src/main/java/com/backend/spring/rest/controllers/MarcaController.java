package com.backend.spring.rest.controllers;

import com.backend.spring.rest.models.Cliente;
import com.backend.spring.rest.models.Marca;
import com.backend.spring.rest.models.Vehiculo;
import com.backend.spring.rest.payload.request.MarcaRequest;
import com.backend.spring.rest.payload.request.VehiculoRequest;
import com.backend.spring.rest.services.ReservaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(("/api/marcas"))

public class MarcaController {

    private ReservaService reservaService;

    public MarcaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @PostMapping("/")

    public ResponseEntity<Marca> saveMarca(@RequestBody MarcaRequest marcaRequest) throws Exception {
        ;return new ResponseEntity<Marca>(reservaService.saveMarca(marcaRequest), HttpStatus.CREATED);
    };
    @GetMapping("/")

    public List<Marca> getAllMarcas(){
        return reservaService.getAllMarcas();
    }

    @GetMapping("{id}")

    public ResponseEntity<Marca> getMarcaById(@PathVariable("id") long marcaId){
        return new ResponseEntity<Marca>(reservaService.getMarcaById(marcaId), HttpStatus.OK);
    }
    @PutMapping("{id}")

    public ResponseEntity<Marca> updateMarca(@PathVariable("id") long marcaId, @RequestBody MarcaRequest marcaRequest){
        return new ResponseEntity<Marca>(reservaService.updateMarca(marcaRequest, marcaId), HttpStatus.OK);}

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteMarcaesBy(@PathVariable("id") long marcaId){
        reservaService.deleteMarca(marcaId);
        return new ResponseEntity<String>("Marca deleted succesfully!.", HttpStatus.OK);
    }

}
