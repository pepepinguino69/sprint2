package com.backend.spring.rest.payload.request;

import com.backend.spring.rest.models.Caracteristica;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@Getter
@Setter
public class ModeloRequest {

    private Long marca_id;
    private String nombre;
    private Long categoria_id;
    private ArrayList<Long> caracteristicas = new ArrayList<>();
    private ArrayList<Long> imagenes = new ArrayList<>();
}
