package com.backend.spring.rest.controllers;



import com.backend.spring.rest.models.Categoria;
import com.backend.spring.rest.models.Reserva;
import com.backend.spring.rest.models.Vehiculo;
import com.backend.spring.rest.payload.request.ReservaRequest;
import com.backend.spring.rest.payload.request.VehiculoRequest;
import com.backend.spring.rest.services.ReservaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(("/api/vehiculos"))

public class VehiculoController {

    private ReservaService reservaService;

    public VehiculoController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }




    @PostMapping("/")

    public ResponseEntity<Vehiculo> saveVehiculo(@RequestBody VehiculoRequest vehiculoRequest){
        ;return new ResponseEntity<Vehiculo>(reservaService.saveVehiculo(vehiculoRequest), HttpStatus.CREATED);
    };
    @GetMapping("/")

    public List<Vehiculo> getAllVehiculos(){
        return reservaService.getAllVehiculos();
    }

    @GetMapping("{id}")

    public ResponseEntity<Vehiculo> getVehiculoById(@PathVariable("id") long vehiculoId){
        return new ResponseEntity<Vehiculo>(reservaService.getVehiculoById(vehiculoId), HttpStatus.OK);
    }
    @PutMapping("{id}")

    public ResponseEntity<Vehiculo> updateVehiculo(@PathVariable("id") long vehiculoId, @RequestBody Vehiculo vehiculo){
        return new ResponseEntity<Vehiculo>(reservaService.updateVehiculo(vehiculo, vehiculoId), HttpStatus.OK);}

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteVehiculoBy(@PathVariable("id") long vehiculoId){
        reservaService.deleteVehiculo(vehiculoId);
        return new ResponseEntity<String>("Vehiculo deleted succesfully!.", HttpStatus.OK);
    }

}
