package com.backend.spring.rest.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Getter
@Setter
@Entity
@Table(name = "marcas")
public class Marca {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "nombre")
    private String nombre;

    private List<Modelo> modeloMar = new ArrayList<>();

    public void addModelo(Modelo modelo) {
        modeloMar.add(modelo);
        modelo.setMarca(this);
    }



}
