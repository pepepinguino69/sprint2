package com.backend.spring.rest.models;


import com.backend.spring.rest.payload.request.ReservaRequest;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import jakarta.persistence.*;
import java.time.LocalDateTime;




@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
@Table(name = "reserva")

public class Reserva {
        @Id
        @Column(name="id")
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private long id;


    @JsonIgnore
        @ManyToOne
        @JoinColumn(
                name = "cliente_id", referencedColumnName = "id",nullable = false,

    foreignKey = @ForeignKey(
            name = "cliente_reserva_fk"
    ))


        private Cliente cliente;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(
               name = "vehiculo_id",
               nullable = false,
               referencedColumnName = "id",
               foreignKey = @ForeignKey(
                       name = "vehiculo_reserva_fk"
               ))

        private Vehiculo vehiculo;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(
            name = "sucursal_id",
            nullable = false,
            referencedColumnName = "id",
            foreignKey = @ForeignKey(
                    name = "sucursal_reserva_fk"
            ))

    private Sucursal sucursal;
        @Column(name="comienzo_reserva",nullable = false)
        private LocalDateTime comienzo_reserva;
        @Column(name="fin_reserva",nullable = false)
        private LocalDateTime fin_reserva;




}



