package com.backend.spring.rest.payload.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
public class ReservaRequest {

   // private ArrayList<Long> conductores= new ArrayList<Long>();
    private Long cliente_id;
    private Long vehiculo_id;
    private Long sucursal_id;
    private LocalDateTime comienzo_reserva;
    private LocalDateTime fin_reserva;



}
